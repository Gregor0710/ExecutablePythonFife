import json
import sys
import os
import settings as st
import subprocess
import settings
import shutil
import zipfile
import subprocess
from tkinter import messagebox
def first_start():
    for path in st.path:
        if os.path.exists(path) == False:
            os.mkdir(path)
            print('EPF: folder create..')
        elif os.path.exists(path) == True:
            print('EPF: there are folders')
    if os.path.exists(st.files[0]) == False:
        with open(st.files[0], 'w', encoding='utf-8') as file1:
            file1.write('Executable Python Fife is a program that creates an executable file for your project,\nwith the .epy extension written in python.\nversion 2.0\nupdate: -up')
            file1.close()
    if os.path.exists(st.files[0]) == True:
         with open(st.files[0], 'r', encoding='utf-8') as file1:
             print(file1.read())
             file1.close()

def install():
    rename = ' '.join(argument[1:2])[:-4] + '.zip'
    os.rename(' '.join(argument[1:2]), rename)

    with zipfile.ZipFile(rename, 'r') as zip_file:
        zip_file.extract('info.json', settings.path[3])
    with open(settings.path[3] + '\\info.json') as jsfile:
        file = json.load(jsfile)
        file_name = file['name']
        name_start_file = file["name_start_file"]
        path = settings.path[1] + '\\' + file['name']
        try:
            os.mkdir(path)
        except FileExistsError:
            answer = messagebox.askyesno(title='install: ' + ' '.join(argument[1:2]), message='file ' + ' '.join(argument[1:2]) + ' is already installed, do you want to update it?')
            if answer:
                pass
            else:
                os.rename(rename, ' '.join(argument[1:2]))
                sys.exit()
    with zipfile.ZipFile(rename, 'r') as zip_file:
        zip_file.extractall(path)
    with open('C:/Programs/' + file_name + '.epy', 'w') as file:
        path = settings.path[1] + '/' + file_name + '/' + name_start_file
        print(path)
        file.write(f'import subprocess\nsubprocess.Popen(r"python {path}", shell=False, stdout=subprocess.PIPE).stdout.read()')
    os.rename(rename, ' '.join(argument[1:2]))
    messagebox.showinfo(title='done!', message='done!')

def main():
    a = subprocess.Popen([f"{settings.files[1]}", ' '.join(argument[1:2])], shell=False, stdout=subprocess.PIPE).stdout.read()
    if a == b'CP1251\n':
        answer = messagebox.askyesno(title='install: ' + ' '.join(argument[1:2]), message='Would you like to install ' + ' '.join(argument[1:2]) + '?')
        if answer:
            print('installing ', ' '.join(argument[1:2]))
            install()
        else:
            pass
    elif a == b'UTF-8\n':
        shutil.copy(' '.join(argument[1:2]), st.path[3] + '\\starting_file.py')
        print(subprocess.Popen(['python ', st.path[3] + '\\starting_file.py'], shell=False, stdout=subprocess.PIPE).stdout.read())
    else:
        messagebox.showinfo(title='info', message='there is no such file, if it is, then move the file to the folder to which the path will be without spaces')

if __name__ == '__main__':
    argument = sys.argv
    first_start()
    main()
