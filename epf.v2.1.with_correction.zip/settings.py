path = ['C:/ProgramData/ExecutablePythonFife',
        'C:/ProgramData/ExecutablePythonFife/programs',
        'C:/ProgramData/ExecutablePythonFife/this_program',
        'C:/ProgramData/ExecutablePythonFife/Temp',
        'C:/Programs']
files = ['C:/ProgramData/ExecutablePythonFife/this_program/info.txt', 'C:/ProgramData/ExecutablePythonFife/this_program/coding.file.exe']