fn main() {
    use std::env;
    use std::process::Command;

// Prints each argument on a separate line
    let arguments: Vec<_> = env::args().collect();
    Command::new("python")
            .arg("main.pyc")
            .args(arguments)
            .spawn()
            .expect("Error: python not installed! If it is not, then add the path to the bin folder to the path environment variables.
            Python can be downloaded and installed from the official website https://www.python.org/downloads/");
}