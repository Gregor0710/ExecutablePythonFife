import wget, os

from . import settings
from .log import write_log_file
def install(app:str):
    wget.download("https://raw.githubusercontent.com/Gregor0710/ExecutablePythonFife/main/applications.py", os.getcwd(), bar=False)
    import applications
    for i in applications.app:
        if app == i[0]:
            try:
                app = settings.path[3] + "\\" + i[0] + ".epy"
                wget.download(i[1], app)
                os.remove("applications.py")
                return app
            except all as err:
                write_log_file(str(os.getcwd()), "EPF.Install.Store.Error >> " + err)
                write_log_file(str(os.getcwd()), "EPF.Install.Store.PrintError >> \"Error:\nPlease download the application from this link:"+i[1]+"\" ")
                print("Error:\n" + "\nPlease download the application from this link: " + i[1])
                os.remove("applications.py")
                return False
        else:
            print("no such app found")
            os.remove("applications.py")
            return False

def list():
    wget.download("https://raw.githubusercontent.com/Gregor0710/ExecutablePythonFife/main/applications.py", os.getcwd(), bar=False)
    import applications
    for i in applications.app:
        print(i[0])
    os.remove("applications.py")
def url(url:str):
    try:
        import random
        r = random.randint(1000,9999)
        app = settings.path[3] + "\\" + str(r) + ".epy"
        wget.download(url, app)
        return app
    except all as err:
        print(err)
        write_log_file(str(os.getcwd()), "PythonError.EPF.Install.Url >> " + err)
        return False