import sys, os
from . import create_link, install, first_start, jjson, settings, InstallApp, dell
def install_(programs):
    if programs == "help":
        print("install")
    else:
        first_start.first_start()
        file_zip = install.file_zip(programs)
        jjson.jsinfo(file_zip)
        chek = install.check_for_creation(settings.path[1] + '\\' + jjson.file_name(), file_zip)
        if chek == "go_install":
            install.unpacking(file_zip, settings.path[1] + '\\' + jjson.file_name())
            create_link.create_link(jjson.file_name(),jjson.icon(file_zip, settings.path[1] + '\\' + jjson.file_name()),settings.path[1] + '\\' + jjson.file_name(), jjson.name_start_file())
            install.file_epy(file_zip)
            for f in os.listdir(settings.path[3]):
                os.remove(os.path.join(settings.path[3], f))
        elif chek == True:
            install.unpacking(file_zip, settings.path[1] + '\\' + jjson.file_name())
            create_link.create_link(jjson.file_name(),
                                    jjson.icon(file_zip, settings.path[1] + '\\' + jjson.file_name()),
                                    settings.path[1] + '\\' + jjson.file_name(), jjson.name_start_file())
            install.file_epy(file_zip)
            for f in os.listdir(settings.path[3]):
                os.remove(os.path.join(settings.path[3], f))
        else:
            for f in os.listdir(settings.path[3]):
                os.remove(os.path.join(settings.path[3], f))
            sys.exit()