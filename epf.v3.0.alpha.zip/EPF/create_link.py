from PIL import Image
import win32com.client
import winshell
from pathlib import Path
import sys
def create_link(file_name, path_icon, path_progect, name_start_file):
    with open(path_progect + "\\main.bat", "w") as file:
        print(name_start_file)
        file.write("echo off\n title " + file_name + "\ncd " + path_progect + "\npython " + name_start_file)
    desktop = winshell.desktop()
    python_path = sys.executable
    filename = path_icon
    img = Image.open(filename)
    img.save(path_progect + "\\icon.ico")
    ws = win32com.client.Dispatch("wscript.shell")
    scut = ws.CreateShortcut(desktop + f'\\{file_name}.lnk')
    scut.TargetPath = str(Path(path_progect + "\\main.bat"))
    scut.IconLocation = path_progect + "\\icon.ico"
    scut.Save()