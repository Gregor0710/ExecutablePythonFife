import os
from . import settings as st
def first_start():
    for path in st.path:
        if os.path.exists(path) == False:
            os.mkdir(path)
            print('EPF: folder create..')
        elif os.path.exists(path) == True:
            print('EPF: there are folders')
    if os.path.exists(st.files[0]) == False:
        with open(st.files[0], 'w', encoding='utf-8') as file1:
            file1.write('Executable Python Fife is a program that creates an executable file for your project,\nwith the .epy extension written in python.\nversion 3.0\nthe app has been completely rewritten.\nmany features added\nhelp: --help')
            file1.close()
    if os.path.exists(st.files[0]) == True:
         with open(st.files[0], 'r', encoding='utf-8') as file1:
             print(file1.read())
             file1.close()