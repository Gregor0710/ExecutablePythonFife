import sys
import zipfile, os
from tkinter import messagebox


def file_zip(file_path):
    print(file_path)
    rename = file_path[:-4] + '.zip'
    os.rename(file_path, rename)
    return rename
    # sys.exit()

def file_epy(file_path):
    rename = file_path[:-4] + '.epy'
    os.rename(file_path, rename)
    return rename

def check_for_creation(path, rename):
    try:
        os.mkdir(path)
        return "go_install"
    except FileExistsError:
        file_name = rename[:-4] + '.epy'
        answer = messagebox.askyesno(title='install: ' + file_name, message='file ' + file_name + ' is already installed, do you want to update it?')
        if answer:
            return True
        else:
            file_name = rename[:-4] + '.epy'
            os.rename(rename, file_name)
            return False
def unpacking(file_, path):
    with zipfile.ZipFile(file_, 'r') as zip_file:
        zip_file.extractall(path)
    return True