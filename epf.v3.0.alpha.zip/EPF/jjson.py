import zipfile, json
from . import settings

def jsinfo(name):
    with zipfile.ZipFile(name, 'r') as zip_file:
        zip_file.extract('info.json', settings.path[3])
def file_name():
    with open(settings.path[3] + '\\info.json') as jsfile:
        file = json.load(jsfile)
        file_name = file['name']
        return file_name
def name_start_file():
    with open(settings.path[3] + '\\info.json') as jsfile:
        file = json.load(jsfile)
        name_start_file = file["name_start_file"]
        return name_start_file
def icon(file_zip, path_progect):
    with open(settings.path[3] + '\\info.json') as jsfile:
        file = json.load(jsfile)
        icon = file["name_icon.png"]
        with zipfile.ZipFile(file_zip, "r") as ico:
            ico.extract(icon, path_progect)
        return path_progect + "\\" + icon
def id():
    with open(settings.path[3] + '\\info.json') as jsfile:
        file = json.load(jsfile)
        id = file["id"]
        return id