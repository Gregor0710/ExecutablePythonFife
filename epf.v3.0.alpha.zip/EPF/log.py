from datetime import datetime as dt
from . import settings
def start_log_file(func=False):
    if func == False or func == True or func == None:
        func = ""
    else:
        func = "-" + str(func)
    global logfile
    logfile = settings.path[5] + "/" + str(dt.now()).replace(" ", "_").replace(":",";")[:-7] + func + ".log"
    with open(logfile, "w") as log:
        log.write("logfile:")
def write_log_file(app:str,argument:str):
    with open(logfile, "a") as file:
        string_ = '\n[("'+ app + '")(' + str(dt.now())[:-7] + ')(' + argument + ')]'
        file.write(string_)