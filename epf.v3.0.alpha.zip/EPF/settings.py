path = ['C:/ProgramData/ExecutablePythonFife', #0
        'C:/ProgramData/ExecutablePythonFife/programs', #1
        'C:/ProgramData/ExecutablePythonFife/this_program', #2
        'C:/ProgramData/ExecutablePythonFife/Temp',#3
        'C:/Programs',#4
        'C:/ProgramData/ExecutablePythonFife/logs']#5
files = ['C:/ProgramData/ExecutablePythonFife/this_program/info.txt', 'C:/ProgramData/ExecutablePythonFife/this_program/coding.file.exe']