import os
import EPF
import sys
import threading
from EPF.log import write_log_file
from EPF.log import start_log_file
from tkinter import messagebox
def update():
    os.system(f'python "{os.path.abspath("update//update.py")}\"')
def main():
    if len(argument) < 2:
        start_log_file("EPF.InvalidArgument")
        write_log_file(str(os.getcwd()), "EPF.Error >> NoneArgument")
        print("EPF.Error >> NoneArgument\nEPF.exe --help")
    elif argument[1] == "--update":
        start_log_file("EPF.Update")
        write_log_file(str(os.getcwd()), "EPF.Update >> StartUpdate")
        x = threading.Thread(target=update)
        x.start()
        write_log_file(str(os.getcwd()), "EPF.Update >> InstallDone")
        sys.exit()
    elif argument[1] == "--help":
        start_log_file("EPF.Help")
        with open("EPF\\help.txt") as help:
            print(help.read())
            write_log_file(str(os.getcwd()), "EPF.Help >> " + help.read())
    elif argument[1] == "--install":
        start_log_file("EPF.Install")
        if argument[2] == "--list":
            write_log_file(str(os.getcwd()), "EPF.Install.List >> " + EPF.InstallApp.list())
        elif argument[2] == "--url":
            write_log_file(str(os.getcwd()), "EPF.Install.Url >> url: " + argument[3])
            i = EPF.InstallApp.url(argument[3])
            if i == False:
                write_log_file(str(os.getcwd()), "EPF.Install.Url >> False")
                pass
            else:
                write_log_file(str(os.getcwd()), "EPF.Install.Url.App >> " + i)
                EPF.install_(i)
        else:
            print("installing " + argument[2])
            write_log_file(str(os.getcwd()), "EPF.Installing >> " + argument[2])
            install = EPF.InstallApp.install(argument[2])
            if install == False:
                write_log_file(str(os.getcwd()), "EPF.Installing,Store >> False")
                pass
            else:
                write_log_file(str(os.getcwd()), "EPF.Installing.Store >> "  + install)
                print(install)
                EPF.install_(install)
    elif argument[1] == "--dell":
        start_log_file("EPF.Delete")
        if argument[2] == "--app":
            write_log_file(str(os.getcwd()), "EPF.Delete.App >> " + argument[3])
            EPF.dell.app(argument[3])
        elif argument[2] == "--.":
            try:
                start_log_file("EPF.Delete.EPF")
                write_log_file(str(os.getcwd()), "EPF.Delete.EPF >> :(")
                A = "dell.exe " + str(EPF.settings.path[2]).replace("/", "\\")
                print(A)
                os.system(A)
                write_log_file(str(os.getcwd()), "EPF.Delete.EPF >> Done:(")
                messagebox.showinfo("Done!")
            except:
                pass
    else:
        for i in argument[1]:
            if i == "-":
                print("EPF.Error>>\nthere is no such argument.\n Type --help to open the help menu")
            else:
                start_log_file("EPF.Install_")
                write_log_file(str(os.getcwd()), "EPF.Install_ >> " + argument[1])
                for i in Path(argument[1]).suffixes:
                    if i != ".epy" or i != ".zip":
                        print("EPF.Error.File>> this file is not suitable")
                    else:
                        EPF.install_(argument[1])
if __name__ == '__main__':
    from pathlib import Path
    try:
        from PIL import Image
    except ModuleNotFoundError:
        import os

        os.system("pip install Pillow")
        from PIL import Image
    try:
        import win32com.client
    except ModuleNotFoundError:
        import os

        os.system("python -m pip install pywin32")
        try:
            import win32com.client
        except ModuleNotFoundError:
            os.system("python -m pip install pypiwin32")
    try:
        import winshell
    except ModuleNotFoundError:
        import os

        os.system("pip install winshell")
        import winshell
    try:
        import wget
    except ModuleNotFoundError:
        os.system("pip install wget")
        import wget
    argument = sys.argv
    argument.pop(1)
    main()