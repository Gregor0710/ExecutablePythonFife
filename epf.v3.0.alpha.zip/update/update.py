try:
    import wget
except ModuleNotFoundError:
    import os
    os.system("pip install wget")
    import wget
import shutil
import os
import zipfile
url = 'https://raw.githubusercontent.com/Gregor0710/ExecutablePythonFife/main/upd.upd'
filename = wget.download(url, f'C:\ProgramData\ExecutablePythonFife\Temp')
# print('\n', os.curdir)
print(os.path.abspath(filename))
shutil.copy(os.path.abspath(filename), f'C:\ProgramData\ExecutablePythonFife\Temp\-update.txt')
with open('C:\ProgramData\ExecutablePythonFife\Temp\-update.txt') as update:
    dict = list(filter(None, update.read().split('\n')))
    # print(dict)
    # print(dict)
    dc = []
    dc1 = []
    for d in dict:
        dc.append(d.split('='))
    # print(dc)
    vr = 1
    ve = []
    for g in dc:
        # print(g)
        print('=::= ', str(vr) + ".", str(g[0])[:-4], ' =::=')
        dc1.append(str(vr) + ' ' + g[0])
        ve.append(g[1])
        vr = vr + 1
        # print(dc)
    inp = input('version download: ')
    for num in dc1:
        # print(num.split('='))
        if inp == num[0]:
            inp1 = int(inp) - 1
            print('download: ', ve[inp1])
            url = ve[inp1]
            filename = wget.download(url)
            with zipfile.ZipFile(filename, 'r') as zip_file:
                zip_file.extractall(r'C:\ProgramData\ExecutablePythonFife\this_program')
            print('Done!')
        else:
            print("ERROR")
folder = 'C:\ProgramData\ExecutablePythonFife\Temp'
for the_file in os.listdir(folder):
    file_path = os.path.join(folder, the_file)
    try:
        if os.path.isfile(file_path):
            os.unlink(file_path)
        elif os.path.isdir(file_path):
            shutil.rmtree(file_path)
    except Exception as e:
        print(e)


# ver = 1
# vr = 0
# g = 1
# # print(len(dc1))
# for num in range(len(dc1)):
     # print(str(num), ' : ', dc1[vr])
